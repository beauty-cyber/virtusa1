package myprogram.org;

public interface IVehicle {
	public abstract void drive();
	public abstract void turnLeft();
	public abstract void brake();

}
