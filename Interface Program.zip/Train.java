package myprogram.org;

public class Train implements IVehicle,IPublicTransport{
	public void getNumberOfPeople()
	{
		System.out.println("In the train there were many people");
	}
	public void  drive()
	{
		System.out.println("The train is moving");
	}
	public void turnLeft()
	{
		System.out.println("The train is turning left");
	}
	public void brake()
	{
		System.out.println("The train is in brake mode");
	}

}
