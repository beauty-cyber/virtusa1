package myprogram.org;

public class Test {

	public static void main(String[] args) {
		Car c=new Car();
		c.checkMotor();
		c.drive();
		c.turnLeft();
		c.brake();
		Train T=new Train();
		T.getNumberOfPeople();
		T.drive();
		T.turnLeft();
		T.brake();

	}

}
