package myprogram.org;

public interface IPublicTransport {
	public abstract void getNumberOfPeople();

}
