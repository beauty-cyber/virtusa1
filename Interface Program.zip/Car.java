package myprogram.org;

public class Car extends MotorisedVehicle implements IVehicle{
	public void  drive()
	{
		System.out.println("The car is moving");
	}
	public void turnLeft()
	{
		System.out.println("The car turning left");
	}
	public void brake()
	{
		System.out.println("The car is in brake mode");
	}
	
	
}
